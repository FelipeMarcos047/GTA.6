const form = document.getElementById("form-planejador");
const mensagensErro = document.getElementById("mensagens-erro");
const painelResultado = document.getElementById("painel-resultado");
const btnLimpar = document.getElementById("btn-limpar");

const campoApelido = document.getElementById("apelido-jogador");
const campoDias = document.getElementById("dias-semana");
const campoHorasSessao = document.getElementById("horas-sessao");
const campoMetaSemanal = document.getElementById("meta-semanal");
const campoEstilo = document.getElementById("estilo-foco");

const camposValidaveis = [campoApelido, campoDias, campoHorasSessao, campoMetaSemanal];

function formatarHoras(valor) {
    return `${valor.toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 })}h`;
}

function escaparTexto(texto) {
    const div = document.createElement("div");
    div.textContent = texto;
    return div.innerHTML;
}

function limparErrosVisuais() {
    mensagensErro.hidden = true;
    mensagensErro.innerHTML = "";
    camposValidaveis.forEach((campo) => {
        campo.classList.remove("campo-invalido");
        campo.removeAttribute("aria-invalid");
    });
}

function marcarErro(campo) {
    campo.classList.add("campo-invalido");
    campo.setAttribute("aria-invalid", "true");
}

form.addEventListener("submit", function (evento) {
    evento.preventDefault();
    limparErrosVisuais();

    const erros = [];
    const apelido = campoApelido.value.trim();
    const dias = Number(campoDias.value);
    const horasSessao = Number(campoHorasSessao.value);
    const temMeta = campoMetaSemanal.value.trim() !== "";
    const metaSemanal = temMeta ? Number(campoMetaSemanal.value) : 10;

    if (apelido.length < 2) {
        erros.push("Informe um apelido ou nome com pelo menos 2 caracteres.");
        marcarErro(campoApelido);
    }

    if (!Number.isInteger(dias) || dias < 1 || dias > 7) {
        erros.push("Os dias por semana devem ser um número inteiro entre 1 e 7.");
        marcarErro(campoDias);
    }

    if (!Number.isFinite(horasSessao) || horasSessao < 0.5 || horasSessao > 12) {
        erros.push("As horas por sessão devem estar entre 0,5h e 12h.");
        marcarErro(campoHorasSessao);
    }

    if (temMeta && (!Number.isFinite(metaSemanal) || metaSemanal < 1 || metaSemanal > 84)) {
        erros.push("A meta semanal deve estar entre 1h e 84h.");
        marcarErro(campoMetaSemanal);
    }

    if (erros.length > 0) {
        const itensLista = erros.map((msg) => `<li>${escaparTexto(msg)}</li>`).join("");
        mensagensErro.innerHTML = `<strong>Revise os campos abaixo antes de calcular:</strong><ul>${itensLista}</ul>`;
        mensagensErro.hidden = false;
        mensagensErro.scrollIntoView({ behavior: "smooth", block: "nearest" });
        return;
    }

    const totalSemanal = dias * horasSessao;
    const diferencaMeta = totalSemanal - metaSemanal;
    const estiloTexto =
        campoEstilo.value === "historia"
            ? "Missões e história principal"
            : "Exploração livre pelo mapa";

    let situacaoMeta = "";
    if (Math.abs(diferencaMeta) < 0.05) {
        situacaoMeta = `Meta exata atingida (${formatarHoras(metaSemanal)})`;
    } else if (diferencaMeta > 0) {
        situacaoMeta = `+${formatarHoras(diferencaMeta)} acima da meta (${formatarHoras(metaSemanal)})`;
    } else {
        situacaoMeta = `${formatarHoras(Math.abs(diferencaMeta))} abaixo da meta (${formatarHoras(metaSemanal)})`;
    }

    painelResultado.innerHTML = `
        <h3>Resumo da rotina</h3>
        <ul class="resumo-lista">
            <li><span>Jogador</span><strong>${escaparTexto(apelido)}</strong></li>
            <li><span>Estilo da semana</span><strong>${escaparTexto(estiloTexto)}</strong></li>
            <li><span>Frequência</span><strong>${dias} dia(s) × ${formatarHoras(horasSessao)}</strong></li>
            <li><span>Comparação com a meta</span><strong>${escaparTexto(situacaoMeta)}</strong></li>
        </ul>
        <p class="total-destaque">Total semanal calculado: ${formatarHoras(totalSemanal)}</p>
    `;
});

btnLimpar.addEventListener("click", function () {
    limparErrosVisuais();
    painelResultado.innerHTML = `
        <h3>Resumo da rotina</h3>
        <p class="resultado-vazio">Preencha os campos ao lado e clique em <strong>Calcular horas</strong> para ver o total semanal e a comparação com a meta.</p>
    `;
});
