# GTA 6 — Central do Fã-Clube (Página Única)

- **Tema:** Fã-clube e planejador de jogatina inspirado em GTA 6
- **Autor:** Felipe Marcos
- **Turma:** 2º DSM1
- **Unidade Curricular:** Desenvolvimento de sistemas - Programação de aplicativos

## Descrição

Página única desenvolvida em HTML5, CSS3 e JavaScript puro para um fã-clube de **GTA 6** adequado ao ambiente escolar. O site apresenta seções sobre os protagonistas, cenários e veículos de Vice City, além de um formulário interativo com validação de dados e cálculo de horas semanais de jogo.

## Regras de validação do formulário

- **Apelido ou nome:** obrigatório, com mínimo de 2 caracteres.
- **Dias por semana:** número inteiro entre 1 e 7.
- **Horas por sessão:** número entre 0,5h e 12h.
- **Meta semanal (opcional):** quando informada, deve ficar entre 1h e 84h (caso fique em branco, assume 10h como referência).

## Estrutura do repositório

- `index.html`: estrutura semântica da página única, navegação, destaques e formulário.
- `css/style.css`: layout responsivo para computador e celular, cartões e indicação visual de erros e foco de teclado.
- `js/script.js`: validação dos campos no envio, exibição de mensagens de erro e cálculo do total de horas semanais e diferença em relação à meta.
- `img/`: imagens locais utilizadas no site (`jasonelucia.jpg`, `carros.jpg`, `jasoneluciabebendo.jpg` e `jasoneluciaarmado.jpg`).
- `README.md`: documentação do projeto, regras de validação e origem das imagens.

## Como executar

1. Extraia o arquivo ZIP em uma pasta chamada `pagina-tema-livre`.
2. Abra o arquivo `index.html` no navegador (ou utilize a extensão *Live Server* no Visual Studio Code).

## Origem dos recursos e imagens

- `img/jasonelucia.jpg`: material promocional oficial de *Grand Theft Auto VI* (Rockstar Games), utilizado para fins educacionais.
- `img/carros.jpg`: material promocional oficial de *Grand Theft Auto VI* (Rockstar Games), utilizado para fins educacionais.
- `img/jasoneluciabebendo.jpg`: material promocional oficial de *Grand Theft Auto VI* (Rockstar Games), utilizado para fins educacionais.
- `img/jasoneluciaarmado.jpg`: material promocional oficial de *Grand Theft Auto VI* (Rockstar Games), utilizado para fins educacionais.
